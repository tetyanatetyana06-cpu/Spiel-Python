import pytest
from src.frage_ohne_index import FrageOhneIndex


def test_richtige_antwort(monkeypatch):
    frage = FrageOhneIndex("Wie heißt die Hauptstadt von Deutschland?", "Berlin")

    # Simuliere Eingabe "Berlin"
    monkeypatch.setattr('builtins.input', lambda _: "Berlin")

    assert frage.stellen() == True


def test_falsche_antwort(monkeypatch):
    frage = FrageOhneIndex("Wie heißt die Hauptstadt von Deutschland?", "Berlin")

    # Simuliere Eingabe "München"
    monkeypatch.setattr('builtins.input', lambda _: "München")

    assert frage.stellen() == False


def test_zahl_varianten_werden_als_richtig_akzeptiert():
    frage = FrageOhneIndex(
        "Wie hoch ist die Arbeitsproduktivität?",
        "2.00",
        accepted_answers=["2", "2,00", "2 Tische", "2,00 Tische"],
    )

    assert frage.is_correct("2") is True
    assert frage.is_correct("2,00") is True
    assert frage.is_correct("2 Tische") is True
    assert frage.is_correct("2,00 Tische") is True
    assert frage.is_correct("2.50") is False