from src.category import Category
from src.logic import QuizEngine
from src.question import Frage


def test_attempts_are_counted_immediately_per_answer():
    category = Category(
        "Test",
        [
            Frage("Frage 1", ["A", "B", "C"], 2),
            Frage("Frage 2", ["A", "B", "C"], 1),
        ],
    )
    engine = QuizEngine([category])

    assert engine.select_category_by_index(0) is True

    result = engine.submit_answer(1, timed_out=False)

    assert result.correct is False
    assert engine.summary()["by_category"][0]["attempts"] == 1
    assert engine.summary()["by_category"][0]["failed_attempts"] == 1
